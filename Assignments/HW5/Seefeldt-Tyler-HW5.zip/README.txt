# Author 
Tyler Seefeldt

# File Descriptions

## Scheduler.cpp: The driver program that calls the different scheduling
algorithms

## README.txt: This file.