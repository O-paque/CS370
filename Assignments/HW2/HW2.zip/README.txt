# Author 
Tyler Seefeldt

# File Descriptions

## Coordinator.c: Forks a child process and waits for the result. Loops through all
command line arguments given to it with the first argument as a divisor and the
remaining arguments as dividends.

## Checker.c: Takes the two arguments passed to it and checks if the dividend would
have a remainder with the current divisor. If remainder is true, return 0, else
return the result of the calculation.

## Makefile: A Makefile made using information provided in the linked Infospaces
video ending in 277

## README.txt: This file.